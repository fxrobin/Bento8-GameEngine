These are SMPS2ASM-converted Sonic 2 SFX files, which can theoretically be made to work with any SMPS driver.

You can find more of these, from different games, at:
http://forums.sonicretro.org/index.php?showtopic=26876

Note that these are not stock; I (Clownacy) have made modifications to these files, to fix several bug-causing mistakes within. The mistakes fixed include:
- Incorrect track transpose value in 'BC - Spin Dash Release.asm'
- Incorrect smpsVcTotalLevel values in 'D5 - Sliding Spike.asm'
- Incorrect smpsVcTotalLevel values in 'DC - Fire.asm'
- Incorrect smpsAlterVol usage in 'DC - Fire.asm'
- Incorrect smpsAlterVol usage in 'EF - Large Laser.asm'
- Incorrect smpsAlterVol usage in 'F0 - Oil Slide.asm'
